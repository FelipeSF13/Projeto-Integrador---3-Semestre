//login
document.addEventListener('DOMContentLoaded', function() {
  const closeButton = document.getElementById('close-top-bar');
  const topBar = document.getElementById('top-bar');

  if (closeButton && topBar) {
    closeButton.addEventListener('click', function() {
      topBar.style.display = 'none';
    });
  }
});


//carrinho 
document.addEventListener('DOMContentLoaded', function() {
  // --- LÓGICA DA BARRA SUPERIOR ---
  const closeButton = document.getElementById('close-top-bar');
  const topBar = document.getElementById('top-bar');

  if (closeButton && topBar) {
    closeButton.addEventListener('click', function() {
      topBar.style.display = 'none';
    });
  }

  // --- LÓGICA DO CARRINHO DE COMPRAS ---
  const cartItemsContainer = document.getElementById('cart-items');
  
  // Função para formatar números como moeda brasileira (BRL)
  const formatCurrency = (value) => {
    return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  };

  // Função principal para atualizar os totais
  const updateCartSummary = () => {
    const cartItems = document.querySelectorAll('.cart-item');
    const shippingCost = 15.99;
    let subtotal = 0;

    cartItems.forEach(item => {
      const price = parseFloat(item.dataset.price);
      const quantity = parseInt(item.querySelector('.quantity-value').textContent);
      subtotal += price * quantity;
    });

    const discount = subtotal * 0.20;
    const total = subtotal - discount + shippingCost;

    document.getElementById('subtotal').textContent = formatCurrency(subtotal);
    // Formata o desconto para sempre mostrar um valor negativo
    document.getElementById('discount').textContent = `-${formatCurrency(discount)}`;
    document.getElementById('shipping').textContent = formatCurrency(shippingCost);
    document.getElementById('total').textContent = formatCurrency(total);
  };

  // Lógica para os botões de quantidade e exclusão
  if (cartItemsContainer) {
    cartItemsContainer.addEventListener('click', function(event) {
      const target = event.target;
      const cartItem = target.closest('.cart-item');

      if (!cartItem) return;

      const quantityValueElement = cartItem.querySelector('.quantity-value');
      let quantity = parseInt(quantityValueElement.textContent);

      // Aumentar quantidade
      if (target.classList.contains('increase-qty')) {
        quantity++;
        quantityValueElement.textContent = quantity;
        updateCartSummary();
      }

      // Diminuir quantidade
      if (target.classList.contains('decrease-qty')) {
        if (quantity > 1) {
          quantity--;
          quantityValueElement.textContent = quantity;
          updateCartSummary();
        }
      }

      // Remover item
      if (target.closest('.delete-item-btn')) {
        cartItem.remove();
        updateCartSummary();
      }
    });
  }

  // Calcula o valor inicial ao carregar a página
  updateCartSummary();
});


//index
document.addEventListener('DOMContentLoaded', function() {
  // --- LÓGICA DA BARRA SUPERIOR ---
  const closeButton = document.getElementById('close-top-bar');
  const topBar = document.getElementById('top-bar');

  if (closeButton && topBar) {
    closeButton.addEventListener('click', function() {
      topBar.style.display = 'none';
    });
  }

  // --- LÓGICA DO CARRINHO DE COMPRAS (se aplicável na página) ---
  const cartItemsContainer = document.getElementById('cart-items');
  
  const formatCurrency = (value) => {
    if (typeof value !== 'number') return '';
    return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  };

  const updateCartSummary = () => {
    if (!document.getElementById('subtotal')) return; // Só executa se os elementos do resumo existirem

    const cartItems = document.querySelectorAll('.cart-item');
    const shippingCost = 15.99;
    let subtotal = 0;

    cartItems.forEach(item => {
      const price = parseFloat(item.dataset.price);
      const quantity = parseInt(item.querySelector('.quantity-value').textContent);
      subtotal += price * quantity;
    });

    const discount = subtotal * 0.20;
    const total = subtotal - discount + shippingCost;

    document.getElementById('subtotal').textContent = formatCurrency(subtotal);
    document.getElementById('discount').textContent = `-${formatCurrency(discount)}`;
    document.getElementById('shipping').textContent = formatCurrency(shippingCost);
    document.getElementById('total').textContent = formatCurrency(total);
  };

  if (cartItemsContainer) {
    cartItemsContainer.addEventListener('click', function(event) {
      const target = event.target;
      const cartItem = target.closest('.cart-item');

      if (!cartItem) return;

      const quantityValueElement = cartItem.querySelector('.quantity-value');
      let quantity = parseInt(quantityValueElement.textContent);

      if (target.classList.contains('increase-qty')) {
        quantity++;
        quantityValueElement.textContent = quantity;
        updateCartSummary();
      }

      if (target.classList.contains('decrease-qty')) {
        if (quantity > 1) {
          quantity--;
          quantityValueElement.textContent = quantity;
          updateCartSummary();
        }
      }

      if (target.closest('.delete-item-btn')) {
        cartItem.remove();
        updateCartSummary();
      }
    });
  }

  // Calcula o valor inicial do carrinho ao carregar a página (se estiver na página do carrinho)
  updateCartSummary();

  // --- LÓGICA DO CARROSSEL DE FEEDBACK ---
  const feedbackGrid = document.querySelector('.feedback-grid');
  if (feedbackGrid && feedbackGrid.children.length > 0) {
    const feedbackCards = Array.from(feedbackGrid.children);
    let currentIndex = 0;

    // Injeta os estilos CSS necessários para o carrossel
    const style = document.createElement('style');
    style.textContent = `
      .feedback-grid {
        display: flex; /* Altera o display para flex para o carrossel */
        overflow: hidden;
      }
      .feedback-card {
        flex: 0 0 100%; /* Garante que cada card ocupe o espaço total */
        transition: transform 0.5s ease-in-out;
      }
      .feedback-dots-container {
        text-align: center;
        margin-top: 1rem;
      }
      .feedback-dot {
        height: 12px;
        width: 12px;
        margin: 0 5px;
        background-color: #ddd;
        border-radius: 50%;
        display: inline-block;
        cursor: pointer;
        transition: background-color 0.3s ease;
      }
      .feedback-dot.active {
        background-color: #555;
      }
    `;
    document.head.appendChild(style);

    // Cria o container para os pontos de navegação
    const dotsContainer = document.createElement('div');
    dotsContainer.classList.add('feedback-dots-container');
    feedbackGrid.insertAdjacentElement('afterend', dotsContainer);

    // Cria um ponto para cada card de feedback
    feedbackCards.forEach((_, index) => {
      const dot = document.createElement('span');
      dot.classList.add('feedback-dot');
      dot.addEventListener('click', () => {
        showFeedback(index);
      });
      dotsContainer.appendChild(dot);
    });

    const dots = dotsContainer.querySelectorAll('.feedback-dot');

    const showFeedback = (index) => {
      feedbackGrid.style.transform = `translateX(-${index * 100}%)`;
      dots.forEach((dot, i) => {
        dot.classList.toggle('active', i === index);
      });
      currentIndex = index;
    };

    const nextFeedback = () => {
      const nextIndex = (currentIndex + 1) % feedbackCards.length;
      showFeedback(nextIndex);
    };

    // Inicia o carrossel automático
    setInterval(nextFeedback, 5000); // Troca de slide a cada 5 segundos

    // Mostra o primeiro feedback e ativa o primeiro ponto
    showFeedback(0);
  }
});

